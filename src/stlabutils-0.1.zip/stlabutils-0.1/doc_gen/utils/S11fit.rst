S11fit -- Resonance fitting routines and utilities
==================================================

.. automodule:: stlabutils.utils.S11fit
  :exclude-members: diff_find_resonance, find_resonance, background2min,
      S11residual
  :members:
