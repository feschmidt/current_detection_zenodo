TLmodel -- Model for transmission line resonator
================================================

.. automodule:: stlabutils.utils.TLmodel
  :members:
