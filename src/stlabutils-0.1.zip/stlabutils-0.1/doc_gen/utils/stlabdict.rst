stlabdict -- Data structures and matrices
=========================================

.. automodule:: stlabutils.utils.stlabdict
  :special-members:
  :members:
  :exclude-members: __weakref__
