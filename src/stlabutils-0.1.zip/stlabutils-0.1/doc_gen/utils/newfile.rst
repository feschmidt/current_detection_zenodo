newfile -- New measurement folder creation
==========================================

.. automodule:: stlabutils.utils.newfile
  :members:

