writematrix -- Data file writing methods
========================================

.. automodule:: stlabutils.utils.writematrix
  :members:

