Metagen -- Spyview metafile generation
======================================

.. automodule:: stlabutils.utils.metagen
  :members:

