Autoplot -- Quick plots for measurement reference
=================================================

.. automodule:: stlabutils.utils.autoplotter
  :members:

