.. _instrument_class:

The instrument class
====================

.. automodule:: stlab.devices.instrument
  :special-members:
  :members:

Instrument autodetection
------------------------

A function to autodetect instruments and load the correct driver is also provided

.. autofunction:: stlab.devices.autodetect_instrument.autodetect_instrument