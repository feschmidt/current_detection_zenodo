.. Test documentation master file, created by
   sphinx-quickstart on Mon Sep 10 12:04:37 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. image:: https://img.shields.io/badge/source-github-ff69b4.svg
   :target: https://github.com/steelelab-delft/stlab

.. image:: https://img.shields.io/badge/License-GPLv3-blue.svg
   :target: https://www.gnu.org/licenses/gpl-3.0

.. image:: https://zenodo.org/badge/DOI/10.5281/zenodo.1299278.svg
   :target: https://doi.org/10.5281/zenodo.1299278

Documentation for STLab
=======================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   :glob:

   utils/*
   drivers/*

Introduction
============

STLab is a collection of drivers and scripts used for equipment control and measurement
automation.  For the most part it is built upon pyvisa and is inteded to avoid the complications
of low level communication with measurement instruments without including an inconvenient level
of additional complexity (see `KISS principle <https://en.wikipedia.org/wiki/KISS_principle>`_).

STLab needs `stlabutils <https://github.com/steelelab-delft/stlabutils>`_ for saving measurements, but can be used alone for only communication.

The instrument drivers should in general only contain basic commonly used commands and not
sophisticated setup and measurement schemes.  While things like "Get power" or "Get Trace" are
acceptable, methods like "Perform 2 tone measurement" should not be included in basic device drivers.
The latter kind of method should reside on a higher level of abstration since its use is likely
to be very specific and would only clutter the driver for others.

The basic structure of the package is as follows:

| stlab
| ├── __init__.py
| ├── LICENCE.md
| ├── README.md
| ├── devices
| │   ├── instrument.py
| │   └── instrument drivers
| │   ├── 
| ├── utils
| │   ├── 
| │   └── ...
| ├── examples
| │   ├── ...
| │   └── ...
| ├── docs
| │   ├── ...
| │   └── ...
| ├── doc_gen
| │   ├── ...
| │   └── ...

* The "devices" folder contains all the implemented drivers as well as the basic instrument class.
* The "utils" folder contains modules for running in the background. All old modules that was not directly related to instrument communication has been moved to `stlabutils <https://github.com/steelelab-delft/stlabutils>`_.
* "examples" contains a collection of basic script examples suchs as VNA power sweeps or quick Q factor measurements and fits.
* "docs" contains this documentation and "doc_gen" contains the sphynx scripts for generating it.
* The __init__.py file contains the modules and names imported when running "import stlab".  Note that some modules and functions are renamed for (in?)convenience.

The imports done when doing :code:`import stlab` are:

.. literalinclude:: ../__init__.py
  :language: python

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

License
=======

stlab is licensed under the `GNU General Public License v3.0 
<https://www.gnu.org/licenses/gpl-3.0.en.html>`_.
